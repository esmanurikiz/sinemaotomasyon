﻿namespace Sinematik.com
{
    partial class FrmFilmKayit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFilmKayit));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtFilmAdi = new System.Windows.Forms.TextBox();
            this.grBTur = new System.Windows.Forms.GroupBox();
            this.lblBilimKurgu = new System.Windows.Forms.Label();
            this.lblPsikoloji = new System.Windows.Forms.Label();
            this.lblGerilim = new System.Windows.Forms.Label();
            this.lblKomedi = new System.Windows.Forms.Label();
            this.lblKorku = new System.Windows.Forms.Label();
            this.lblAksiyon = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.grBOzellik = new System.Windows.Forms.GroupBox();
            this.pb6 = new System.Windows.Forms.PictureBox();
            this.lblOnSekiz = new System.Windows.Forms.Label();
            this.lblOnUc = new System.Windows.Forms.Label();
            this.lblYedi = new System.Windows.Forms.Label();
            this.lblGenelIzleyici = new System.Windows.Forms.Label();
            this.lblOlumsuzIcerik = new System.Windows.Forms.Label();
            this.lblKorkuSiddet = new System.Windows.Forms.Label();
            this.pb3 = new System.Windows.Forms.PictureBox();
            this.pb5 = new System.Windows.Forms.PictureBox();
            this.pb4 = new System.Windows.Forms.PictureBox();
            this.pb2 = new System.Windows.Forms.PictureBox();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.grBicim = new System.Windows.Forms.GroupBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.lblIngilizce = new System.Windows.Forms.Label();
            this.lblAltyazı = new System.Windows.Forms.Label();
            this.lblTurkce = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lblYonetmenAra = new System.Windows.Forms.Label();
            this.txtYonetmenAra = new System.Windows.Forms.TextBox();
            this.fYonetmenPaneli = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.lblOyuncuAra = new System.Windows.Forms.Label();
            this.txtOyuncuAra = new System.Windows.Forms.TextBox();
            this.fOyuncuPaneli = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.lblSaat = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblTarih = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.nYil = new System.Windows.Forms.NumericUpDown();
            this.nAy = new System.Windows.Forms.NumericUpDown();
            this.nGun = new System.Windows.Forms.NumericUpDown();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.lblRating = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.rB10 = new System.Windows.Forms.RadioButton();
            this.rB6 = new System.Windows.Forms.RadioButton();
            this.rB9 = new System.Windows.Forms.RadioButton();
            this.rB1 = new System.Windows.Forms.RadioButton();
            this.rB8 = new System.Windows.Forms.RadioButton();
            this.rB2 = new System.Windows.Forms.RadioButton();
            this.rB7 = new System.Windows.Forms.RadioButton();
            this.rB3 = new System.Windows.Forms.RadioButton();
            this.rB4 = new System.Windows.Forms.RadioButton();
            this.rB5 = new System.Windows.Forms.RadioButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btnResimYukle = new System.Windows.Forms.Button();
            this.pBResim = new System.Windows.Forms.PictureBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txtFilmDetay = new System.Windows.Forms.TextBox();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grBTur.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grBOzellik.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            this.grBicim.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nYil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nAy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nGun)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBResim)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1030, 50);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Italic);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 35);
            this.label1.TabIndex = 2;
            this.label1.Text = "(FİLM KAYIT EKRANI)";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Maroon;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Dock = System.Windows.Forms.DockStyle.Right;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(967, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(63, 50);
            this.button1.TabIndex = 1;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.groupBox1.Controls.Add(this.txtFilmAdi);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.groupBox1.Location = new System.Drawing.Point(9, 67);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.groupBox1.Size = new System.Drawing.Size(325, 57);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "FİLM ADI";
            // 
            // txtFilmAdi
            // 
            this.txtFilmAdi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.txtFilmAdi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFilmAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtFilmAdi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.txtFilmAdi.Location = new System.Drawing.Point(13, 24);
            this.txtFilmAdi.Name = "txtFilmAdi";
            this.txtFilmAdi.Size = new System.Drawing.Size(306, 27);
            this.txtFilmAdi.TabIndex = 0;
            this.txtFilmAdi.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // grBTur
            // 
            this.grBTur.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.grBTur.Controls.Add(this.lblBilimKurgu);
            this.grBTur.Controls.Add(this.lblPsikoloji);
            this.grBTur.Controls.Add(this.lblGerilim);
            this.grBTur.Controls.Add(this.lblKomedi);
            this.grBTur.Controls.Add(this.lblKorku);
            this.grBTur.Controls.Add(this.lblAksiyon);
            this.grBTur.Controls.Add(this.pictureBox7);
            this.grBTur.Controls.Add(this.pictureBox6);
            this.grBTur.Controls.Add(this.pictureBox5);
            this.grBTur.Controls.Add(this.pictureBox4);
            this.grBTur.Controls.Add(this.pictureBox3);
            this.grBTur.Controls.Add(this.pictureBox1);
            this.grBTur.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grBTur.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.grBTur.Location = new System.Drawing.Point(9, 130);
            this.grBTur.Name = "grBTur";
            this.grBTur.Padding = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.grBTur.Size = new System.Drawing.Size(325, 140);
            this.grBTur.TabIndex = 6;
            this.grBTur.TabStop = false;
            this.grBTur.Text = "FİLM TÜRLERİ";
            // 
            // lblBilimKurgu
            // 
            this.lblBilimKurgu.AutoSize = true;
            this.lblBilimKurgu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblBilimKurgu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBilimKurgu.ForeColor = System.Drawing.Color.Black;
            this.lblBilimKurgu.Location = new System.Drawing.Point(197, 104);
            this.lblBilimKurgu.Name = "lblBilimKurgu";
            this.lblBilimKurgu.Size = new System.Drawing.Size(118, 20);
            this.lblBilimKurgu.TabIndex = 23;
            this.lblBilimKurgu.Text = "BİLİM KURGU";
            this.lblBilimKurgu.Click += new System.EventHandler(this.lblBilimKurgu_Click);
            // 
            // lblPsikoloji
            // 
            this.lblPsikoloji.AutoSize = true;
            this.lblPsikoloji.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPsikoloji.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPsikoloji.ForeColor = System.Drawing.Color.Black;
            this.lblPsikoloji.Location = new System.Drawing.Point(197, 67);
            this.lblPsikoloji.Name = "lblPsikoloji";
            this.lblPsikoloji.Size = new System.Drawing.Size(95, 20);
            this.lblPsikoloji.TabIndex = 22;
            this.lblPsikoloji.Text = "PSİKOLOJİ";
            this.lblPsikoloji.Click += new System.EventHandler(this.lblPsikoloji_Click);
            // 
            // lblGerilim
            // 
            this.lblGerilim.AutoSize = true;
            this.lblGerilim.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblGerilim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGerilim.ForeColor = System.Drawing.Color.Black;
            this.lblGerilim.Location = new System.Drawing.Point(197, 32);
            this.lblGerilim.Name = "lblGerilim";
            this.lblGerilim.Size = new System.Drawing.Size(77, 20);
            this.lblGerilim.TabIndex = 21;
            this.lblGerilim.Text = "GERİLİM";
            this.lblGerilim.Click += new System.EventHandler(this.lblGerilim_Click);
            // 
            // lblKomedi
            // 
            this.lblKomedi.AutoSize = true;
            this.lblKomedi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblKomedi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKomedi.ForeColor = System.Drawing.Color.Black;
            this.lblKomedi.Location = new System.Drawing.Point(58, 104);
            this.lblKomedi.Name = "lblKomedi";
            this.lblKomedi.Size = new System.Drawing.Size(75, 20);
            this.lblKomedi.TabIndex = 20;
            this.lblKomedi.Text = "KOMEDİ";
            this.lblKomedi.Click += new System.EventHandler(this.lblKomedi_Click);
            // 
            // lblKorku
            // 
            this.lblKorku.AutoSize = true;
            this.lblKorku.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblKorku.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKorku.ForeColor = System.Drawing.Color.Black;
            this.lblKorku.Location = new System.Drawing.Point(58, 67);
            this.lblKorku.Name = "lblKorku";
            this.lblKorku.Size = new System.Drawing.Size(68, 20);
            this.lblKorku.TabIndex = 19;
            this.lblKorku.Text = "KORKU";
            this.lblKorku.Click += new System.EventHandler(this.lblKorku_Click);
            // 
            // lblAksiyon
            // 
            this.lblAksiyon.AutoSize = true;
            this.lblAksiyon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblAksiyon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAksiyon.ForeColor = System.Drawing.Color.Black;
            this.lblAksiyon.Location = new System.Drawing.Point(58, 32);
            this.lblAksiyon.Name = "lblAksiyon";
            this.lblAksiyon.Size = new System.Drawing.Size(81, 20);
            this.lblAksiyon.TabIndex = 18;
            this.lblAksiyon.Text = "AKSİYON";
            this.lblAksiyon.Click += new System.EventHandler(this.lblAksiyon_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(151, 98);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(40, 30);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 17;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(151, 62);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(40, 30);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 16;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(151, 27);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(40, 30);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 15;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(12, 98);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(40, 30);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 14;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(12, 62);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(40, 30);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 13;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // grBOzellik
            // 
            this.grBOzellik.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.grBOzellik.Controls.Add(this.pb6);
            this.grBOzellik.Controls.Add(this.lblOnSekiz);
            this.grBOzellik.Controls.Add(this.lblOnUc);
            this.grBOzellik.Controls.Add(this.lblYedi);
            this.grBOzellik.Controls.Add(this.lblGenelIzleyici);
            this.grBOzellik.Controls.Add(this.lblOlumsuzIcerik);
            this.grBOzellik.Controls.Add(this.lblKorkuSiddet);
            this.grBOzellik.Controls.Add(this.pb3);
            this.grBOzellik.Controls.Add(this.pb5);
            this.grBOzellik.Controls.Add(this.pb4);
            this.grBOzellik.Controls.Add(this.pb2);
            this.grBOzellik.Controls.Add(this.pb1);
            this.grBOzellik.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grBOzellik.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.grBOzellik.Location = new System.Drawing.Point(9, 276);
            this.grBOzellik.Name = "grBOzellik";
            this.grBOzellik.Padding = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.grBOzellik.Size = new System.Drawing.Size(325, 140);
            this.grBOzellik.TabIndex = 7;
            this.grBOzellik.TabStop = false;
            this.grBOzellik.Text = "FİLM ÖZELLİKLERİ";
            // 
            // pb6
            // 
            this.pb6.Image = ((System.Drawing.Image)(resources.GetObject("pb6.Image")));
            this.pb6.Location = new System.Drawing.Point(219, 90);
            this.pb6.Name = "pb6";
            this.pb6.Size = new System.Drawing.Size(30, 20);
            this.pb6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb6.TabIndex = 30;
            this.pb6.TabStop = false;
            // 
            // lblOnSekiz
            // 
            this.lblOnSekiz.AutoSize = true;
            this.lblOnSekiz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblOnSekiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOnSekiz.ForeColor = System.Drawing.Color.Black;
            this.lblOnSekiz.Location = new System.Drawing.Point(255, 91);
            this.lblOnSekiz.Name = "lblOnSekiz";
            this.lblOnSekiz.Size = new System.Drawing.Size(37, 20);
            this.lblOnSekiz.TabIndex = 29;
            this.lblOnSekiz.Text = "+18";
            this.lblOnSekiz.Click += new System.EventHandler(this.lblOnSekiz_Click);
            // 
            // lblOnUc
            // 
            this.lblOnUc.AutoSize = true;
            this.lblOnUc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblOnUc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOnUc.ForeColor = System.Drawing.Color.Black;
            this.lblOnUc.Location = new System.Drawing.Point(255, 59);
            this.lblOnUc.Name = "lblOnUc";
            this.lblOnUc.Size = new System.Drawing.Size(37, 20);
            this.lblOnUc.TabIndex = 28;
            this.lblOnUc.Text = "+13";
            this.lblOnUc.Click += new System.EventHandler(this.lblOnUc_Click);
            // 
            // lblYedi
            // 
            this.lblYedi.AutoSize = true;
            this.lblYedi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblYedi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblYedi.ForeColor = System.Drawing.Color.Black;
            this.lblYedi.Location = new System.Drawing.Point(255, 29);
            this.lblYedi.Name = "lblYedi";
            this.lblYedi.Size = new System.Drawing.Size(28, 20);
            this.lblYedi.TabIndex = 27;
            this.lblYedi.Text = "+7";
            this.lblYedi.Click += new System.EventHandler(this.lblYedi_Click);
            // 
            // lblGenelIzleyici
            // 
            this.lblGenelIzleyici.AutoSize = true;
            this.lblGenelIzleyici.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblGenelIzleyici.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGenelIzleyici.ForeColor = System.Drawing.Color.Black;
            this.lblGenelIzleyici.Location = new System.Drawing.Point(49, 90);
            this.lblGenelIzleyici.Name = "lblGenelIzleyici";
            this.lblGenelIzleyici.Size = new System.Drawing.Size(135, 20);
            this.lblGenelIzleyici.TabIndex = 26;
            this.lblGenelIzleyici.Text = "GENEL İZLEYİCİ";
            this.lblGenelIzleyici.Click += new System.EventHandler(this.lblGenelIzleyici_Click);
            // 
            // lblOlumsuzIcerik
            // 
            this.lblOlumsuzIcerik.AutoSize = true;
            this.lblOlumsuzIcerik.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblOlumsuzIcerik.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOlumsuzIcerik.ForeColor = System.Drawing.Color.Black;
            this.lblOlumsuzIcerik.Location = new System.Drawing.Point(49, 59);
            this.lblOlumsuzIcerik.Name = "lblOlumsuzIcerik";
            this.lblOlumsuzIcerik.Size = new System.Drawing.Size(149, 20);
            this.lblOlumsuzIcerik.TabIndex = 25;
            this.lblOlumsuzIcerik.Text = "OLUMSUZ İÇERİK";
            this.lblOlumsuzIcerik.Click += new System.EventHandler(this.lblOlumsuzIcerik_Click);
            // 
            // lblKorkuSiddet
            // 
            this.lblKorkuSiddet.AutoSize = true;
            this.lblKorkuSiddet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblKorkuSiddet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKorkuSiddet.ForeColor = System.Drawing.Color.Black;
            this.lblKorkuSiddet.Location = new System.Drawing.Point(49, 29);
            this.lblKorkuSiddet.Name = "lblKorkuSiddet";
            this.lblKorkuSiddet.Size = new System.Drawing.Size(135, 20);
            this.lblKorkuSiddet.TabIndex = 24;
            this.lblKorkuSiddet.Text = "KORKU/ŞİDDET";
            this.lblKorkuSiddet.Click += new System.EventHandler(this.lblKorkuSiddet_Click);
            // 
            // pb3
            // 
            this.pb3.Image = ((System.Drawing.Image)(resources.GetObject("pb3.Image")));
            this.pb3.Location = new System.Drawing.Point(12, 90);
            this.pb3.Name = "pb3";
            this.pb3.Size = new System.Drawing.Size(30, 20);
            this.pb3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb3.TabIndex = 23;
            this.pb3.TabStop = false;
            // 
            // pb5
            // 
            this.pb5.Image = ((System.Drawing.Image)(resources.GetObject("pb5.Image")));
            this.pb5.Location = new System.Drawing.Point(219, 59);
            this.pb5.Name = "pb5";
            this.pb5.Size = new System.Drawing.Size(30, 20);
            this.pb5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb5.TabIndex = 22;
            this.pb5.TabStop = false;
            // 
            // pb4
            // 
            this.pb4.Image = ((System.Drawing.Image)(resources.GetObject("pb4.Image")));
            this.pb4.Location = new System.Drawing.Point(219, 29);
            this.pb4.Name = "pb4";
            this.pb4.Size = new System.Drawing.Size(30, 20);
            this.pb4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb4.TabIndex = 21;
            this.pb4.TabStop = false;
            // 
            // pb2
            // 
            this.pb2.Image = ((System.Drawing.Image)(resources.GetObject("pb2.Image")));
            this.pb2.Location = new System.Drawing.Point(13, 59);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(30, 20);
            this.pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb2.TabIndex = 19;
            this.pb2.TabStop = false;
            // 
            // pb1
            // 
            this.pb1.Image = ((System.Drawing.Image)(resources.GetObject("pb1.Image")));
            this.pb1.Location = new System.Drawing.Point(13, 29);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(30, 20);
            this.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb1.TabIndex = 18;
            this.pb1.TabStop = false;
            // 
            // grBicim
            // 
            this.grBicim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.grBicim.Controls.Add(this.pictureBox15);
            this.grBicim.Controls.Add(this.pictureBox14);
            this.grBicim.Controls.Add(this.pictureBox13);
            this.grBicim.Controls.Add(this.lblIngilizce);
            this.grBicim.Controls.Add(this.lblAltyazı);
            this.grBicim.Controls.Add(this.lblTurkce);
            this.grBicim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grBicim.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.grBicim.Location = new System.Drawing.Point(9, 422);
            this.grBicim.Name = "grBicim";
            this.grBicim.Padding = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.grBicim.Size = new System.Drawing.Size(325, 140);
            this.grBicim.TabIndex = 8;
            this.grBicim.TabStop = false;
            this.grBicim.Text = "FİLM BİÇİMİ";
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(160, 36);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(40, 30);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 17;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(13, 88);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(40, 30);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox14.TabIndex = 16;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(13, 36);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(40, 30);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 15;
            this.pictureBox13.TabStop = false;
            // 
            // lblIngilizce
            // 
            this.lblIngilizce.AutoSize = true;
            this.lblIngilizce.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblIngilizce.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblIngilizce.ForeColor = System.Drawing.Color.Black;
            this.lblIngilizce.Location = new System.Drawing.Point(59, 93);
            this.lblIngilizce.Name = "lblIngilizce";
            this.lblIngilizce.Size = new System.Drawing.Size(88, 20);
            this.lblIngilizce.TabIndex = 14;
            this.lblIngilizce.Text = "İNGİLİZCE";
            this.lblIngilizce.Click += new System.EventHandler(this.lblIngilizce_Click);
            // 
            // lblAltyazı
            // 
            this.lblAltyazı.AutoSize = true;
            this.lblAltyazı.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblAltyazı.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAltyazı.ForeColor = System.Drawing.Color.Black;
            this.lblAltyazı.Location = new System.Drawing.Point(206, 40);
            this.lblAltyazı.Name = "lblAltyazı";
            this.lblAltyazı.Size = new System.Drawing.Size(74, 20);
            this.lblAltyazı.TabIndex = 13;
            this.lblAltyazı.Text = "ALTYAZI";
            this.lblAltyazı.Click += new System.EventHandler(this.lblAltyazı_Click);
            // 
            // lblTurkce
            // 
            this.lblTurkce.AutoSize = true;
            this.lblTurkce.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblTurkce.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTurkce.ForeColor = System.Drawing.Color.Black;
            this.lblTurkce.Location = new System.Drawing.Point(59, 41);
            this.lblTurkce.Name = "lblTurkce";
            this.lblTurkce.Size = new System.Drawing.Size(77, 20);
            this.lblTurkce.TabIndex = 12;
            this.lblTurkce.Text = "TÜRKÇE";
            this.lblTurkce.Click += new System.EventHandler(this.lblTurkce_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.groupBox5.Controls.Add(this.lblYonetmenAra);
            this.groupBox5.Controls.Add(this.txtYonetmenAra);
            this.groupBox5.Controls.Add(this.fYonetmenPaneli);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.groupBox5.Location = new System.Drawing.Point(353, 67);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.groupBox5.Size = new System.Drawing.Size(325, 203);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "FİLM YÖNETMENLERİ";
            // 
            // lblYonetmenAra
            // 
            this.lblYonetmenAra.AutoSize = true;
            this.lblYonetmenAra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.lblYonetmenAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblYonetmenAra.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblYonetmenAra.Location = new System.Drawing.Point(194, 167);
            this.lblYonetmenAra.Name = "lblYonetmenAra";
            this.lblYonetmenAra.Size = new System.Drawing.Size(97, 20);
            this.lblYonetmenAra.TabIndex = 5;
            this.lblYonetmenAra.Text = "Oyuncu Ara";
            // 
            // txtYonetmenAra
            // 
            this.txtYonetmenAra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.txtYonetmenAra.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtYonetmenAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtYonetmenAra.Location = new System.Drawing.Point(7, 167);
            this.txtYonetmenAra.Name = "txtYonetmenAra";
            this.txtYonetmenAra.Size = new System.Drawing.Size(312, 19);
            this.txtYonetmenAra.TabIndex = 4;
            this.txtYonetmenAra.TextChanged += new System.EventHandler(this.txtYonetmenAra_TextChanged);
            // 
            // fYonetmenPaneli
            // 
            this.fYonetmenPaneli.AutoScroll = true;
            this.fYonetmenPaneli.Location = new System.Drawing.Point(7, 29);
            this.fYonetmenPaneli.Name = "fYonetmenPaneli";
            this.fYonetmenPaneli.Size = new System.Drawing.Size(312, 132);
            this.fYonetmenPaneli.TabIndex = 1;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.groupBox6.Controls.Add(this.lblOyuncuAra);
            this.groupBox6.Controls.Add(this.txtOyuncuAra);
            this.groupBox6.Controls.Add(this.fOyuncuPaneli);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.groupBox6.Location = new System.Drawing.Point(353, 276);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.groupBox6.Size = new System.Drawing.Size(325, 286);
            this.groupBox6.TabIndex = 10;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "FİLM OYUNCULARI";
            // 
            // lblOyuncuAra
            // 
            this.lblOyuncuAra.AutoSize = true;
            this.lblOyuncuAra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.lblOyuncuAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOyuncuAra.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblOyuncuAra.Location = new System.Drawing.Point(194, 253);
            this.lblOyuncuAra.Name = "lblOyuncuAra";
            this.lblOyuncuAra.Size = new System.Drawing.Size(97, 20);
            this.lblOyuncuAra.TabIndex = 2;
            this.lblOyuncuAra.Text = "Oyuncu Ara";
            this.lblOyuncuAra.Click += new System.EventHandler(this.lblOyuncuAra_Click);
            // 
            // txtOyuncuAra
            // 
            this.txtOyuncuAra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.txtOyuncuAra.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOyuncuAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtOyuncuAra.Location = new System.Drawing.Point(7, 253);
            this.txtOyuncuAra.Name = "txtOyuncuAra";
            this.txtOyuncuAra.Size = new System.Drawing.Size(312, 19);
            this.txtOyuncuAra.TabIndex = 1;
            this.txtOyuncuAra.TextChanged += new System.EventHandler(this.txtOyuncuAra_TextChanged);
            // 
            // fOyuncuPaneli
            // 
            this.fOyuncuPaneli.AutoScroll = true;
            this.fOyuncuPaneli.Location = new System.Drawing.Point(7, 39);
            this.fOyuncuPaneli.Name = "fOyuncuPaneli";
            this.fOyuncuPaneli.Size = new System.Drawing.Size(312, 188);
            this.fOyuncuPaneli.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.groupBox7.Controls.Add(this.lblSaat);
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.lblTarih);
            this.groupBox7.Controls.Add(this.label5);
            this.groupBox7.Controls.Add(this.button2);
            this.groupBox7.Controls.Add(this.label3);
            this.groupBox7.Controls.Add(this.label2);
            this.groupBox7.Controls.Add(this.label4);
            this.groupBox7.Controls.Add(this.nYil);
            this.groupBox7.Controls.Add(this.nAy);
            this.groupBox7.Controls.Add(this.nGun);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.groupBox7.Location = new System.Drawing.Point(695, 67);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.groupBox7.Size = new System.Drawing.Size(325, 203);
            this.groupBox7.TabIndex = 11;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "FİLM VİZYON TARİHİ";
            this.groupBox7.Enter += new System.EventHandler(this.groupBox7_Enter);
            // 
            // lblSaat
            // 
            this.lblSaat.AutoSize = true;
            this.lblSaat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSaat.Location = new System.Drawing.Point(130, 167);
            this.lblSaat.Name = "lblSaat";
            this.lblSaat.Size = new System.Drawing.Size(60, 20);
            this.lblSaat.TabIndex = 14;
            this.lblSaat.Text = "lblSaat";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(67, 166);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 20);
            this.label6.TabIndex = 13;
            this.label6.Text = "SAAT:";
            // 
            // lblTarih
            // 
            this.lblTarih.AutoSize = true;
            this.lblTarih.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTarih.Location = new System.Drawing.Point(130, 141);
            this.lblTarih.Name = "lblTarih";
            this.lblTarih.Size = new System.Drawing.Size(64, 20);
            this.lblTarih.TabIndex = 14;
            this.lblTarih.Text = "lblTarih";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(60, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "TARİH:";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(25, 97);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(274, 37);
            this.button2.TabIndex = 12;
            this.button2.Text = "TARİH SEÇ";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(209, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "YIL";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(112, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = "AY";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "GÜN";
            // 
            // nYil
            // 
            this.nYil.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nYil.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Italic);
            this.nYil.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.nYil.Location = new System.Drawing.Point(214, 63);
            this.nYil.Maximum = new decimal(new int[] {
            2100,
            0,
            0,
            0});
            this.nYil.Minimum = new decimal(new int[] {
            1950,
            0,
            0,
            0});
            this.nYil.Name = "nYil";
            this.nYil.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nYil.Size = new System.Drawing.Size(85, 28);
            this.nYil.TabIndex = 7;
            this.nYil.Value = new decimal(new int[] {
            2023,
            0,
            0,
            0});
            // 
            // nAy
            // 
            this.nAy.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nAy.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Italic);
            this.nAy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.nAy.Location = new System.Drawing.Point(117, 63);
            this.nAy.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nAy.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nAy.Name = "nAy";
            this.nAy.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nAy.Size = new System.Drawing.Size(77, 28);
            this.nAy.TabIndex = 8;
            this.nAy.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nGun
            // 
            this.nGun.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nGun.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Italic);
            this.nGun.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.nGun.Location = new System.Drawing.Point(25, 63);
            this.nGun.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
            this.nGun.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nGun.Name = "nGun";
            this.nGun.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nGun.Size = new System.Drawing.Size(65, 28);
            this.nGun.TabIndex = 9;
            this.nGun.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.groupBox8.Controls.Add(this.lblRating);
            this.groupBox8.Controls.Add(this.pictureBox2);
            this.groupBox8.Controls.Add(this.rB10);
            this.groupBox8.Controls.Add(this.rB6);
            this.groupBox8.Controls.Add(this.rB9);
            this.groupBox8.Controls.Add(this.rB1);
            this.groupBox8.Controls.Add(this.rB8);
            this.groupBox8.Controls.Add(this.rB2);
            this.groupBox8.Controls.Add(this.rB7);
            this.groupBox8.Controls.Add(this.rB3);
            this.groupBox8.Controls.Add(this.rB4);
            this.groupBox8.Controls.Add(this.rB5);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.groupBox8.Location = new System.Drawing.Point(699, 276);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.groupBox8.Size = new System.Drawing.Size(123, 286);
            this.groupBox8.TabIndex = 12;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "FİLM IMDB PUANI";
            // 
            // lblRating
            // 
            this.lblRating.AutoSize = true;
            this.lblRating.Location = new System.Drawing.Point(89, 39);
            this.lblRating.Name = "lblRating";
            this.lblRating.Size = new System.Drawing.Size(23, 25);
            this.lblRating.TabIndex = 0;
            this.lblRating.Text = "1";
            this.lblRating.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(69, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(46, 36);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // rB10
            // 
            this.rB10.AutoSize = true;
            this.rB10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rB10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rB10.Location = new System.Drawing.Point(65, 232);
            this.rB10.Name = "rB10";
            this.rB10.Size = new System.Drawing.Size(47, 24);
            this.rB10.TabIndex = 9;
            this.rB10.TabStop = true;
            this.rB10.Text = "10";
            this.rB10.UseVisualStyleBackColor = true;
            this.rB10.CheckedChanged += new System.EventHandler(this.rB10_CheckedChanged);
            // 
            // rB6
            // 
            this.rB6.AutoSize = true;
            this.rB6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rB6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rB6.Location = new System.Drawing.Point(62, 91);
            this.rB6.Name = "rB6";
            this.rB6.Size = new System.Drawing.Size(38, 24);
            this.rB6.TabIndex = 5;
            this.rB6.TabStop = true;
            this.rB6.Text = "6";
            this.rB6.UseVisualStyleBackColor = true;
            this.rB6.CheckedChanged += new System.EventHandler(this.rB6_CheckedChanged);
            // 
            // rB9
            // 
            this.rB9.AutoSize = true;
            this.rB9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rB9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rB9.Location = new System.Drawing.Point(63, 196);
            this.rB9.Name = "rB9";
            this.rB9.Size = new System.Drawing.Size(38, 24);
            this.rB9.TabIndex = 8;
            this.rB9.TabStop = true;
            this.rB9.Text = "9";
            this.rB9.UseVisualStyleBackColor = true;
            this.rB9.CheckedChanged += new System.EventHandler(this.rB9_CheckedChanged);
            // 
            // rB1
            // 
            this.rB1.AutoSize = true;
            this.rB1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rB1.Location = new System.Drawing.Point(12, 91);
            this.rB1.Name = "rB1";
            this.rB1.Size = new System.Drawing.Size(38, 24);
            this.rB1.TabIndex = 0;
            this.rB1.TabStop = true;
            this.rB1.Text = "1";
            this.rB1.UseVisualStyleBackColor = true;
            this.rB1.CheckedChanged += new System.EventHandler(this.rB1_CheckedChanged);
            // 
            // rB8
            // 
            this.rB8.AutoSize = true;
            this.rB8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rB8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rB8.Location = new System.Drawing.Point(63, 161);
            this.rB8.Name = "rB8";
            this.rB8.Size = new System.Drawing.Size(38, 24);
            this.rB8.TabIndex = 7;
            this.rB8.TabStop = true;
            this.rB8.Text = "8";
            this.rB8.UseVisualStyleBackColor = true;
            this.rB8.CheckedChanged += new System.EventHandler(this.rB8_CheckedChanged);
            // 
            // rB2
            // 
            this.rB2.AutoSize = true;
            this.rB2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rB2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rB2.Location = new System.Drawing.Point(13, 127);
            this.rB2.Name = "rB2";
            this.rB2.Size = new System.Drawing.Size(38, 24);
            this.rB2.TabIndex = 1;
            this.rB2.TabStop = true;
            this.rB2.Text = "2";
            this.rB2.UseVisualStyleBackColor = true;
            this.rB2.CheckedChanged += new System.EventHandler(this.rB2_CheckedChanged);
            // 
            // rB7
            // 
            this.rB7.AutoSize = true;
            this.rB7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rB7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rB7.Location = new System.Drawing.Point(62, 126);
            this.rB7.Name = "rB7";
            this.rB7.Size = new System.Drawing.Size(38, 24);
            this.rB7.TabIndex = 6;
            this.rB7.TabStop = true;
            this.rB7.Text = "7";
            this.rB7.UseVisualStyleBackColor = true;
            this.rB7.CheckedChanged += new System.EventHandler(this.rB7_CheckedChanged);
            // 
            // rB3
            // 
            this.rB3.AutoSize = true;
            this.rB3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rB3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rB3.Location = new System.Drawing.Point(13, 162);
            this.rB3.Name = "rB3";
            this.rB3.Size = new System.Drawing.Size(38, 24);
            this.rB3.TabIndex = 2;
            this.rB3.TabStop = true;
            this.rB3.Text = "3";
            this.rB3.UseVisualStyleBackColor = true;
            this.rB3.CheckedChanged += new System.EventHandler(this.rB3_CheckedChanged);
            // 
            // rB4
            // 
            this.rB4.AutoSize = true;
            this.rB4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rB4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rB4.Location = new System.Drawing.Point(12, 197);
            this.rB4.Name = "rB4";
            this.rB4.Size = new System.Drawing.Size(38, 24);
            this.rB4.TabIndex = 3;
            this.rB4.TabStop = true;
            this.rB4.Text = "4";
            this.rB4.UseVisualStyleBackColor = true;
            this.rB4.CheckedChanged += new System.EventHandler(this.rB4_CheckedChanged);
            // 
            // rB5
            // 
            this.rB5.AutoSize = true;
            this.rB5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rB5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rB5.Location = new System.Drawing.Point(12, 232);
            this.rB5.Name = "rB5";
            this.rB5.Size = new System.Drawing.Size(38, 24);
            this.rB5.TabIndex = 4;
            this.rB5.TabStop = true;
            this.rB5.Text = "5";
            this.rB5.UseVisualStyleBackColor = true;
            this.rB5.CheckedChanged += new System.EventHandler(this.rB5_CheckedChanged);
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.groupBox9.Controls.Add(this.btnResimYukle);
            this.groupBox9.Controls.Add(this.pBResim);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.groupBox9.Location = new System.Drawing.Point(851, 276);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.groupBox9.Size = new System.Drawing.Size(169, 286);
            this.groupBox9.TabIndex = 13;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "FİLM AFİŞİ";
            // 
            // btnResimYukle
            // 
            this.btnResimYukle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnResimYukle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnResimYukle.FlatAppearance.BorderSize = 0;
            this.btnResimYukle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResimYukle.ForeColor = System.Drawing.Color.White;
            this.btnResimYukle.Location = new System.Drawing.Point(13, 219);
            this.btnResimYukle.Name = "btnResimYukle";
            this.btnResimYukle.Size = new System.Drawing.Size(143, 37);
            this.btnResimYukle.TabIndex = 3;
            this.btnResimYukle.Text = "YÜKLE";
            this.btnResimYukle.UseVisualStyleBackColor = false;
            this.btnResimYukle.Click += new System.EventHandler(this.btnResimYukle_Click);
            // 
            // pBResim
            // 
            this.pBResim.Image = global::Sinematik.com.Properties.Resources.foto;
            this.pBResim.Location = new System.Drawing.Point(13, 29);
            this.pBResim.Name = "pBResim";
            this.pBResim.Size = new System.Drawing.Size(143, 173);
            this.pBResim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBResim.TabIndex = 2;
            this.pBResim.TabStop = false;
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.groupBox10.Controls.Add(this.txtFilmDetay);
            this.groupBox10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.groupBox10.Location = new System.Drawing.Point(9, 568);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.groupBox10.Size = new System.Drawing.Size(1011, 203);
            this.groupBox10.TabIndex = 14;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "FİLM DETAY";
            // 
            // txtFilmDetay
            // 
            this.txtFilmDetay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.txtFilmDetay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFilmDetay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtFilmDetay.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtFilmDetay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(97)))), ((int)(((byte)(105)))));
            this.txtFilmDetay.Location = new System.Drawing.Point(10, 26);
            this.txtFilmDetay.Multiline = true;
            this.txtFilmDetay.Name = "txtFilmDetay";
            this.txtFilmDetay.Size = new System.Drawing.Size(998, 174);
            this.txtFilmDetay.TabIndex = 1;
            // 
            // btnKaydet
            // 
            this.btnKaydet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnKaydet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKaydet.FlatAppearance.BorderSize = 0;
            this.btnKaydet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKaydet.ForeColor = System.Drawing.Color.White;
            this.btnKaydet.Location = new System.Drawing.Point(353, 777);
            this.btnKaydet.Name = "btnKaydet";
            this.btnKaydet.Size = new System.Drawing.Size(325, 37);
            this.btnKaydet.TabIndex = 15;
            this.btnKaydet.Text = "KAYIT TAMAMLA";
            this.btnKaydet.UseVisualStyleBackColor = false;
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // FrmFilmKayit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(174)))), ((int)(((byte)(187)))));
            this.ClientSize = new System.Drawing.Size(1030, 822);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.btnKaydet);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.grBicim);
            this.Controls.Add(this.grBOzellik);
            this.Controls.Add(this.grBTur);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(500, 50);
            this.Name = "FrmFilmKayit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "FrmFilmKayit";
            this.Load += new System.EventHandler(this.FrmFilmKayit_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grBTur.ResumeLayout(false);
            this.grBTur.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grBOzellik.ResumeLayout(false);
            this.grBOzellik.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            this.grBicim.ResumeLayout(false);
            this.grBicim.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nYil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nAy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nGun)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBResim)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtFilmAdi;
        private System.Windows.Forms.GroupBox grBTur;
        private System.Windows.Forms.GroupBox grBOzellik;
        private System.Windows.Forms.GroupBox grBicim;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button btnKaydet;
        private System.Windows.Forms.TextBox txtFilmDetay;
        private System.Windows.Forms.PictureBox pBResim;
        private System.Windows.Forms.RadioButton rB10;
        private System.Windows.Forms.RadioButton rB9;
        private System.Windows.Forms.RadioButton rB8;
        private System.Windows.Forms.RadioButton rB7;
        private System.Windows.Forms.RadioButton rB6;
        private System.Windows.Forms.RadioButton rB5;
        private System.Windows.Forms.RadioButton rB4;
        private System.Windows.Forms.RadioButton rB3;
        private System.Windows.Forms.RadioButton rB2;
        private System.Windows.Forms.RadioButton rB1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblRating;
        private System.Windows.Forms.Button btnResimYukle;
        private System.Windows.Forms.Label lblOyuncuAra;
        private System.Windows.Forms.TextBox txtOyuncuAra;
        private System.Windows.Forms.FlowLayoutPanel fOyuncuPaneli;
        private System.Windows.Forms.FlowLayoutPanel fYonetmenPaneli;
        private System.Windows.Forms.TextBox txtYonetmenAra;
        private System.Windows.Forms.Label lblYonetmenAra;
        private System.Windows.Forms.Label lblIngilizce;
        private System.Windows.Forms.Label lblAltyazı;
        private System.Windows.Forms.Label lblTurkce;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pb5;
        private System.Windows.Forms.PictureBox pb4;
        private System.Windows.Forms.PictureBox pb2;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pb3;
        private System.Windows.Forms.Label lblAksiyon;
        private System.Windows.Forms.Label lblKomedi;
        private System.Windows.Forms.Label lblKorku;
        private System.Windows.Forms.Label lblBilimKurgu;
        private System.Windows.Forms.Label lblPsikoloji;
        private System.Windows.Forms.Label lblGerilim;
        private System.Windows.Forms.Label lblKorkuSiddet;
        private System.Windows.Forms.Label lblOnSekiz;
        private System.Windows.Forms.Label lblOnUc;
        private System.Windows.Forms.Label lblYedi;
        private System.Windows.Forms.Label lblGenelIzleyici;
        private System.Windows.Forms.Label lblOlumsuzIcerik;
        private System.Windows.Forms.PictureBox pb6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nYil;
        private System.Windows.Forms.NumericUpDown nAy;
        private System.Windows.Forms.NumericUpDown nGun;
        private System.Windows.Forms.Label lblTarih;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblSaat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Timer timer1;
    }
}