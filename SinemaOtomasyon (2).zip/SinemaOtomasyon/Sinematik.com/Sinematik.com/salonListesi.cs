﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sinematik.com
{
    public partial class salonListesi : UserControl
    {
        public salonListesi()
        {
            InitializeComponent();
        }

        private void gel(object sender, MouseEventArgs e)
        {
            lblSalonAdi.ForeColor = Color.DarkRed;
            this.BackColor = Color.FromArgb(187, 174, 187);
        }

        private void ayril(object sender, EventArgs e)
        {
            lblSalonAdi.ForeColor = Color.DimGray;
            this.BackColor = Color.WhiteSmoke;
        }
    }
}
