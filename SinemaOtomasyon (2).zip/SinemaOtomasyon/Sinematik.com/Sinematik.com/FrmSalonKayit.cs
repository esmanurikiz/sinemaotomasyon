﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Xml.Schema;

namespace Sinematik.com
{
    public partial class FrmSalonKayit : Form
    {
        public FrmSalonKayit()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-RGG65VF\\MSSQLSERVER01;Initial Catalog=sinemaDB;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnResimYukle_Click(object sender, EventArgs e)
        {
            if (txtSalonAdi.Text!="" && cbKoltukSayisi.Text!="")
            {
                baglanti.Open();
                SqlCommand kaydet = new SqlCommand("insert into Tbl_Salonlar (SALONADI,KOLTUKSAYISI) Values (@p1,@p2)",baglanti);
                kaydet.Parameters.AddWithValue("@p1",txtSalonAdi.Text.ToUpper());
                kaydet.Parameters.AddWithValue("@p2", cbKoltukSayisi.Text);
                kaydet.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Salon kaydetme işlemi gerçekleştirildi");
                txtSalonAdi.Text = "";
                cbKoltukSayisi.Text = "";
                txtSalonAdi.Focus();
                listeGetir();
            }

            else
            {
                MessageBox.Show("Lütfen bir değer giriniz");
            }
        }

        private void FrmSalonKayit_Load(object sender, EventArgs e)
        {
            listeGetir();
            kOlustur();
        }
        void kOlustur()
        {
            for (int i = 1; i <= 200; i++)
            {
                cbKoltukSayisi.Items.Add(i);
            }

        }
        void listeGetir()
        {
            panelSalon.Controls.Clear();
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from Tbl_Salonlar ORDER BY SALONADI ASC", baglanti);
            SqlDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                salonListesi arac = new salonListesi();
                arac.lblSalonAdi.Text = oku["SALONADI"].ToString();
                arac.lblKoltukSayisi.Text = oku["KOLTUKSAYISI"].ToString();
                panelSalon.Controls.Add(arac);
            }
            baglanti.Close();
        }
    }
}
