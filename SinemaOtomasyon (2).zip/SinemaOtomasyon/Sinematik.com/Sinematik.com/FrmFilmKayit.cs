﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sinematik.com
{
    public partial class FrmFilmKayit : Form
    {
        public FrmFilmKayit()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-RGG65VF\\MSSQLSERVER01;Initial Catalog=sinemaDB;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            verileriSil();
           

        }
        void  verileriSil()
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("delete from Tbl_Secilenler", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
        }
        private void FrmFilmKayit_Load(object sender, EventArgs e)
        {
            oListesiGetir();
            yListesiGetir();
            bugununTarihi();
            txtFilmAdi.Focus();

        }
        void bugununTarihi()
        {
            nGun.Value = DateTime.Today.Day;
            nAy.Value = DateTime.Today.Month;
            nYil.Value = DateTime.Today.Year;
        }
        void oListesiGetir ()
        {
            string sorgu = "select * from Tbl_Oyuncular ORDER BY ADSOYAD ASC ";
            fOyuncuPaneli.Controls.Clear();
            baglanti.Open();
            SqlCommand komut = new SqlCommand(sorgu, baglanti);
            SqlDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                oListeAraci arac = new oListeAraci();
                arac.lblAdi.Text = oku["ADSOYAD"].ToString();
                fOyuncuPaneli.Controls.Add(arac);
            }
            baglanti.Close();
        }

        void yListesiGetir()
        {
            string sorgu = "select * from Tbl_Yonetmenler ORDER BY ADSOYAD ASC ";
            fYonetmenPaneli.Controls.Clear();
            baglanti.Open();
            SqlCommand komut = new SqlCommand(sorgu, baglanti);
            SqlDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                yListeAraci arac = new yListeAraci();
                arac.lblAdi.Text = oku["ADSOYAD"].ToString();
                fYonetmenPaneli.Controls.Add(arac);
            }
            baglanti.Close();
        }

        private void rB1_CheckedChanged(object sender, EventArgs e)
        {
            lblRating.Text = "1";
        }

        private void rB2_CheckedChanged(object sender, EventArgs e)
        {
            lblRating.Text = "2";
        }

        private void rB3_CheckedChanged(object sender, EventArgs e)
        {
            lblRating.Text = "3";
        }

        private void rB4_CheckedChanged(object sender, EventArgs e)
        {
            lblRating.Text = "4";
        }

        private void rB5_CheckedChanged(object sender, EventArgs e)
        {
            lblRating.Text = "5";
        }

        private void rB6_CheckedChanged(object sender, EventArgs e)
        {
            lblRating.Text = "6";
        }

        private void rB7_CheckedChanged(object sender, EventArgs e)
        {
            lblRating.Text = "7";
        }

        private void rB8_CheckedChanged(object sender, EventArgs e)
        {
            lblRating.Text = "8";
        }

        private void rB9_CheckedChanged(object sender, EventArgs e)
        {
            lblRating.Text = "9";
        }

        private void rB10_CheckedChanged(object sender, EventArgs e)
        {
            lblRating.Text = "10";
        }
        public string resimYolu = "";
        private void btnResimYukle_Click(object sender, EventArgs e)
        {
            
            
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "RESİM ÇEKME EKRANI";
            ofd.Filter = "PNG | *.png | JPG-JPEG | *.jpg;*.jpeg | ALL FİLES | *.*";
            ofd.FilterIndex = 3;

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pBResim.Image = new Bitmap(ofd.FileName);
                resimYolu = ofd.FileName.ToString();
            }
        }

        private void lblOyuncuAra_Click(object sender, EventArgs e)
        {

        }

     
        private void txtOyuncuAra_TextChanged(object sender, EventArgs e)
        {

            fOyuncuPaneli.Controls.Clear();
            baglanti.Open();
            SqlCommand ara = new SqlCommand("select * from Tbl_Oyuncular WHERE ADSOYAD LIKE '%" + txtOyuncuAra.Text + "%' ORDER BY ADSOYAD ASC", baglanti);
            SqlDataReader oku = ara.ExecuteReader();
            while (oku.Read())
            {

                oListeAraci arac = new oListeAraci();
                arac.lblAdi.Text = oku["ADSOYAD"].ToString();
                fOyuncuPaneli.Controls.Add(arac);
            }
            baglanti.Close();
        }

        private void txtYonetmenAra_TextChanged(object sender, EventArgs e)
        {
            fYonetmenPaneli.Controls.Clear();
            baglanti.Open();
            SqlCommand ara = new SqlCommand("select * from Tbl_Yonetmenler WHERE ADSOYAD LIKE '%" + txtYonetmenAra.Text + "%' ORDER BY ADSOYAD ASC", baglanti);
            SqlDataReader oku = ara.ExecuteReader();
            while (oku.Read())
            {

                yListeAraci arac = new yListeAraci();
                arac.lblAdi.Text = oku["ADSOYAD"].ToString();
                fYonetmenPaneli.Controls.Add(arac);
            }
            baglanti.Close();
        }

        private void lblGerilim_Click(object sender, EventArgs e)
        {
            if (lblGerilim.ForeColor == Color.Black)
            {
                lblGerilim.ForeColor = Color.Maroon;
            }
            else
            {
                lblGerilim.ForeColor = Color.Black;
            }
        }

        private void lblAksiyon_Click(object sender, EventArgs e)
        {
            if (lblAksiyon.ForeColor == Color.Black)
            {
                lblAksiyon.ForeColor = Color.Maroon;
            }
            else
            {
                lblAksiyon.ForeColor = Color.Black;
            }
        }

        private void lblKorku_Click(object sender, EventArgs e)
        {
            if (lblKorku.ForeColor == Color.Black)
            {
                lblKorku.ForeColor = Color.Maroon;
            }
            else
            {
                lblKorku.ForeColor = Color.Black;
            }
        }

        private void lblKomedi_Click(object sender, EventArgs e)
        {
            if (lblKomedi.ForeColor == Color.Black)
            {
                lblKomedi.ForeColor = Color.Maroon;
            }
            else
            {
                lblKomedi.ForeColor = Color.Black;
            }
        }

        private void lblPsikoloji_Click(object sender, EventArgs e)
        {
            if (lblPsikoloji.ForeColor == Color.Black)
            {
                lblPsikoloji.ForeColor = Color.Maroon;
            }
            else
            {
                lblPsikoloji.ForeColor = Color.Black;
            }
        }

        private void lblBilimKurgu_Click(object sender, EventArgs e)
        {
            if (lblBilimKurgu.ForeColor == Color.Black)
            {
                lblBilimKurgu.ForeColor = Color.Maroon;
            }
            else
            {
                lblBilimKurgu.ForeColor = Color.Black;
            }
        }

        private void lblTurkce_Click(object sender, EventArgs e)
        {
            if (lblTurkce.ForeColor == Color.Black)
            {
                lblTurkce.ForeColor = Color.Maroon;
            }
            else
            {
                lblTurkce.ForeColor = Color.Black;
            }
        }

        private void lblIngilizce_Click(object sender, EventArgs e)
        {
            if (lblIngilizce.ForeColor == Color.Black)
            {
                lblIngilizce.ForeColor = Color.Maroon;
            }
            else
            {
                lblIngilizce.ForeColor = Color.Black;
            }
        }

        private void lblAltyazı_Click(object sender, EventArgs e)
        {
            if (lblAltyazı.ForeColor == Color.Black)
            {
                lblAltyazı.ForeColor = Color.Maroon;
            }
            else
            {
                lblAltyazı.ForeColor = Color.Black;
            }
        }

        private void lblKorkuSiddet_Click(object sender, EventArgs e)
        {
            if (lblKorkuSiddet.ForeColor == Color.Black)
            {
                lblKorkuSiddet.ForeColor = Color.Maroon;
                pb1.ImageLocation = @"C:\Users\Asus\Downloads\kilit.png";
            }
            else
            {
                lblKorkuSiddet.ForeColor = Color.Black;
                pb1.ImageLocation = @"C:\Users\Asus\Downloads\lock.png";
            }
        }

        private void lblOlumsuzIcerik_Click(object sender, EventArgs e)
        {
            if (lblOlumsuzIcerik.ForeColor == Color.Black)
            {
                lblOlumsuzIcerik.ForeColor = Color.Maroon;
                pb2.ImageLocation = @"C:\Users\Asus\Downloads\kilit.png";
            }
            else
            {
                lblOlumsuzIcerik.ForeColor = Color.Black;
                pb2.ImageLocation = @"C:\Users\Asus\Downloads\lock.png";
            }
        }

        private void lblGenelIzleyici_Click(object sender, EventArgs e)
        {
            if (lblGenelIzleyici.ForeColor == Color.Black)
            {
                lblGenelIzleyici.ForeColor = Color.Maroon;
                pb3.ImageLocation = @"C:\Users\Asus\Downloads\kilit.png";
            }
            else
            {
                lblGenelIzleyici.ForeColor = Color.Black;
                pb3.ImageLocation = @"C:\Users\Asus\Downloads\lock.png";
            }
        }

        private void lblYedi_Click(object sender, EventArgs e)
        {
            if (lblYedi.ForeColor == Color.Black)
            {
                lblYedi.ForeColor = Color.Maroon;
                pb4.ImageLocation = @"C:\Users\Asus\Downloads\kilit.png";

            }
            else
            {
                lblYedi.ForeColor = Color.Black;
                pb4.ImageLocation = @"C:\Users\Asus\Downloads\lock.png";
            }
        }

        private void lblOnUc_Click(object sender, EventArgs e)
        {
            if (lblOnUc.ForeColor == Color.Black)
            {
                lblOnUc.ForeColor = Color.Maroon;
                pb5.ImageLocation = @"C:\Users\Asus\Downloads\kilit.png";
            }
            else
            {
                lblOnUc.ForeColor = Color.Black;
                pb5.ImageLocation = @"C:\Users\Asus\Downloads\lock.png";
            }
        }

        private void lblOnSekiz_Click(object sender, EventArgs e)
        {
            if (lblOnSekiz.ForeColor == Color.Black)
            {
                lblOnSekiz.ForeColor = Color.Maroon;
                pb6.ImageLocation = @"C:\Users\Asus\Downloads\kilit.png";
            }
            else
            {
                lblOnSekiz.ForeColor = Color.Black;
                pb6.ImageLocation = @"C:\Users\Asus\Downloads\lock.png";
            }
        }

        private void groupBox7_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            vizyonTarihiHesapla();

        }
        string vTarih = "";
        string durum = "0";

        void vizyonTarihiHesapla()
        {
            vTarih= nGun.Value + "-"+nAy.Value +"-"+nYil.Value;
            DateTime dVTarih = Convert.ToDateTime(vTarih);
            DateTime bugunTarihi = DateTime.Today;

            TimeSpan tSpan = dVTarih - bugunTarihi;

            if (tSpan.TotalDays<0)
            {
                MessageBox.Show("GEÇMİŞ TARİHLERE AİT FİLM SEÇİMİ YAPILAMAZ");
                bugununTarihi();
            }
            else if (tSpan.TotalDays==0) 
            {
                MessageBox.Show(txtFilmAdi.Text.ToUpper() + " FİLMİ BUGÜN VİZYONDA");
                durum = "1";
            }
            else
            {
                MessageBox.Show(txtFilmAdi.Text.ToUpper()+" "+tSpan.TotalDays.ToString() + " GÜN SONRA VİZYONA GİRECEKTİR");
                durum = "0";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTarih.Text= DateTime.Now.ToShortDateString();
            lblSaat.Text= DateTime.Now.ToShortTimeString();
        }
        string yonetmen = "";
        string oyuncu = "";
        

        void secilenYonetmen()
        {
            yonetmen = "";
            string sorgu = "select * from Tbl_Secilenler where TUR='YÖNETMEN'";
            baglanti.Open();
            SqlCommand komut = new SqlCommand(sorgu,baglanti);
            SqlDataReader oku = komut.ExecuteReader();
            
            while (oku.Read())
            {
                yonetmen += " ," + oku["KISI"].ToString();
            }
            baglanti.Close();
        }
        void secilenOyuncu()
        {
            oyuncu = "";
            string sorgu = "select * from Tbl_Secilenler where TUR='OYUNCU'";
            baglanti.Open();
            SqlCommand komut = new SqlCommand(sorgu, baglanti);
            SqlDataReader oku = komut.ExecuteReader();

            while (oku.Read())
            {
                oyuncu += " ," + oku["KISI"].ToString();
            }
            baglanti.Close();
        }
        void temizlemeMetodu()
        {
            this.Controls.Clear();
            this.InitializeComponent();
            txtFilmAdi.Focus();
            verileriSil();
            yListesiGetir();
            oListesiGetir();
            bugununTarihi();

        }
        private void btnKaydet_Click(object sender, EventArgs e)
        {
            secilenYonetmen();
            secilenOyuncu();
            tur();
            ozellik();
            bicim();



            if (txtFilmAdi.Text!="" && txtFilmDetay.Text!="" && yonetmen!="" && oyuncu!="" && resimYolu!="" && vTarih!="" && secilenBicim!="" && secilenOzellik!="" && secilenTur!="")
            {

                string sorgu = "insert into Tbl_Filmler (ADI,TURU,OZELLIKLERI,BICIMI,YONETMEN,OYUNCU,DETAY,PUAN,AFIS,TARIH,DURUM) values (@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10,@p11)";
                baglanti.Open();
                SqlCommand komut = new SqlCommand(sorgu, baglanti);
                komut.Parameters.AddWithValue("@p1", txtFilmAdi.Text.ToUpper());
                if (secilenTur.Length > 2)
                {

                    komut.Parameters.AddWithValue("@p2", secilenTur.Substring(2));
                }
                else
                {
                    komut.Parameters.AddWithValue("@p2", secilenTur);
                }


                if (secilenOzellik.Length > 2)
                {

                    komut.Parameters.AddWithValue("@p3", secilenOzellik.Substring(2));
                }
                else
                {
                    komut.Parameters.AddWithValue("@p3", secilenOzellik);
                }
                if (secilenBicim.Length > 2)
                {

                    komut.Parameters.AddWithValue("@p4", secilenBicim.Substring(2));
                }
                else
                {
                    komut.Parameters.AddWithValue("@p4", secilenBicim);
                }
                if (yonetmen.Length > 2)
                {

                    komut.Parameters.AddWithValue("@p5", yonetmen.Substring(2));
                }
                else
                {
                    komut.Parameters.AddWithValue("@p5", yonetmen);
                }

                if (oyuncu.Length > 2)
                {

                    komut.Parameters.AddWithValue("@p6", oyuncu.Substring(2));
                }
                else
                {
                    komut.Parameters.AddWithValue("@p6", oyuncu);
                }
                komut.Parameters.AddWithValue("@p7", txtFilmDetay.Text.ToUpper());
                komut.Parameters.AddWithValue("@p8", lblRating.Text);
                komut.Parameters.AddWithValue("@p9", resimYolu);
                komut.Parameters.AddWithValue("@p10", vTarih);
                komut.Parameters.AddWithValue("@p11", durum);
                komut.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Film kaydı başarılı bir şekilde eklendi");
                temizlemeMetodu();
            }
            else
            {
                MessageBox.Show("Lütfen tüm alanları doldurunuz");
            }
            
        }

        string secilenTur = "";
        string secilenOzellik = "";
        string secilenBicim = "";

        void tur()
        {
            secilenTur = "";
            foreach(Control arac in grBTur.Controls)
            {
                if (arac is Label)
                {
                    if (arac.ForeColor== Color.Black)
                    {

                    }
                    else
                    {
                        secilenTur += " ," + arac.Text.ToString();
                    }
                }
            }
        }
        void ozellik()
        {
            secilenOzellik = "";
            foreach (Control arac in grBOzellik.Controls)
            {
                if (arac is Label)
                {
                    if (arac.ForeColor == Color.Black)
                    {

                    }
                    else
                    {
                        secilenOzellik += " ," + arac.Text.ToString();
                    }
                }
            }
        }
        void bicim()
        {
            secilenBicim = "";
            foreach (Control arac in grBicim.Controls)
            {
                if (arac is Label)
                {
                    if (arac.ForeColor == Color.Black)
                    {

                    }
                    else
                    {
                        secilenBicim += " ," + arac.Text.ToString();
                    }
                }
            }
        }
    }
}
